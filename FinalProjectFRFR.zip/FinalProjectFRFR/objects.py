# A. Import the sqlite library
import sqlite3
from database import *

class Song:
    # 1. Create the constructor function
    def __init__(self, name="", zip="", telephone="",email="", category="" ):
        self.__name = name
        self.__zip = zip
        self.__telephone = telephone
        self.__email = email
        self.__category = category

    # 2. Create a function that returns the name and year released
    def getStr(self):
        # Example string returned by this function
        #
        #        "Monty Python and the Holy Grail (1975)"
        #
        return self.__name + " ("  + str(self.__zip) + ")" + " ("  + str(self.__telephone) + ")"+ " ("  + str(self.__email) + ")"+ " ("  + str(self.__category) + ")"
#--------------------------------------------------------------------------------
# NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW
#--------------------------------------------------------------------------------
# Add a new method to use ROWFACTORY (Column names instead of column position)
    @classmethod
    def getAllCustomers(cls):
        # A. Connection to the database
        con = sqlite3.connect('gc.db')

        #------------------------------------------------------------------------
        # CHANGED LINE OF CODE BELOW
        #------------------------------------------------------------------------
        # A1. Add in row_factory.  This will allow us to use column names instead
        #     of guess which column position number our data is in
        con.row_factory = sqlite3.Row

        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT * FROM Customer;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        custList = []

        for individualRow in allRows:
            c = {"CustomerID" : individualRow["CustomerID"], "Name" : individualRow["Name"], "ZIP": individualRow["ZIP"], "Telephone": individualRow["Telephone"], "Email": individualRow["Email"], "Category": individualRow["Category"] }
            custList.append(c)
        return custList
    def getSingleCustomer(ID):
        con = sqlite3.connect('gc.db')
        con.row_factory = sqlite3.Row
        cursorObj = con.cursor()
        customer = []
        cursorObj.execute('SELECT * FROM Customer where CustomerID = ?;',(ID,))
        rows = cursorObj.fetchall()
        for row in rows:
            s = {"Name" : row["Name"], "ZIP" : row["ZIP"] }
            customer.append(s)
        return customer

class Product:
    # 1. Create the constructor function
    def __init__(self, name="", color="", price=""):
        self.__name = name
        self.__color = color
        self.__price = price

    # 2. Create a function that returns the name and year released
    def getStr(self):
        # Example string returned by this function
        #
        #        "Monty Python and the Holy Grail (1975)"
        #
        return self.__name + " ("  + str(self.__color) + ")" + " ("  + str(self.__color) + ")"+ " ("  + str(self.__price) + ")"

#--------------------------------------------------------------------------------
# NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW
#--------------------------------------------------------------------------------
# Add a new method to use ROWFACTORY (Column names instead of column position)
    @classmethod
    def getAllProducts(cls):
        # A. Connection to the database
        con = sqlite3.connect('gc.db')

        #------------------------------------------------------------------------
        # CHANGED LINE OF CODE BELOW
        #------------------------------------------------------------------------
        # A1. Add in row_factory.  This will allow us to use column names instead
        #     of guess which column position number our data is in
        con.row_factory = sqlite3.Row

        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT * FROM Products ;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        prodList = []

        for individualRow in allRows:
            c = {"ProductID" : individualRow["ProductID"], "ProductName" : individualRow["ProductName"], "Color": individualRow["Color"], "Price": individualRow["Price"] }
            prodList.append(c)
        return prodList
    def getBOMByID(id):
        con = sqlite3.connect('gc.db')
        con.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()
        #B. Write a SQL statement to output part number and quantity of the product chosen
        sql = 'SELECT PartNumber, Quantity FROM BOM WHERE ProductID = ?;'
        cursorObj.execute(sql, (id,))
        allRows = cursorObj.fetchall()
        cList = []
        for individualRow in allRows:
            c = {"PartNumber" : individualRow["PartNumber"], "Quantity" : individualRow["Quantity"]}
            cList.append(c)
        return cList # list of partnum-quantity pairs

    def enoughMaterials(materialsNeeded, quantity): #list of dictionaries {PartNumber, Quantity} and quantity from the form
        con = sqlite3.connect('gc.db')
        con.row_factory = sqlite3.Row
        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()
        for mq in materialsNeeded: # for each material dictionary check if the quantity is available
            sql = 'SELECT QuantityAvailable FROM Materials WHERE SWPartNum = ?;'
            partNum = mq["PartNumber"]
            cursorObj.execute(sql, (partNum,)) # getting the partID from the inputted list
            allRows = cursorObj.fetchall() # should only be 1 row
            for individualRow in allRows:
                c = {"QuantityAvailable" : individualRow["QuantityAvailable"]}
                if int(c["QuantityAvailable"]) < int(mq["Quantity"])* int(quantity): #eventually needs to include quantity but unsure how to do that
                    # print('debug')
                    # print(int(c["QuantityAvailable"]) < int(mq["Quantity"]* quantity))
                    # print(int(c["QuantityAvailable"]))
                    # print(int(mq["Quantity"]* quantity))
                    # print(int(mq["Quantity"]* int(quantity)))
                    # print(mq["PartNumber"])
                    # print(mq["Quantity"])
                    return False
        return True

        # #B. Write a SQL statement to output part number and quantity of the product chosen
        # sql = 'SELECT SWPartNum, QuantityAvailable FROM Products WHERE ProductID = ?;'
        # cursorObj.execute(sql, (
        # ,))
        # allRows = cursorObj.fetchall()
        # cList = []
        # for individualRow in allRows:
        #     c = {"Color" : individualRow["Color"]}
        #     cList.append(c)
        # return cList
    def getProdPriceByID(ID):
        con = sqlite3.connect('gc.db')
        con.row_factory = sqlite3.Row
        cursorObj = con.cursor()
        product = []
        cursorObj.execute('SELECT * FROM Products where ProductID = ?;',(ID,))
        rows = cursorObj.fetchall()
        for row in rows:
            s = {"Price" : row["Price"]}
            product.append(s)
        return product

class Supplier:
    # 1. Create the constructor function
    def __init__(self, name="", zip="", telephone="", email=""):
        self.__name = name
        self.__zip = zip
        self.__telephone = telephone
        self.__email = email

    # 2. Create a function that returns the name and year released
    def getStr(self):
        return self.__name + " ("  + str(self.__zip) + ")" + " ("  + str(self.__telephone) + ")"+ " ("  + str(self.__email) + ")"
    @classmethod
    def getAllSuppliers(cls):

        # A. Connection to the database
        con = sqlite3.connect('gc.db')
        con.row_factory = sqlite3.Row

        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT * FROM Suppliers;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        suppList = []

        for individualRow in allRows:
            s = {"SupplierID" : individualRow["SupplierID"], "SupplierName" : individualRow["SupplierName"], "ZIP": individualRow["ZIP"], "Telephone": individualRow["Telephone"], "Email": individualRow["Email"] }
            suppList.append(s)
        return suppList

class Invoice:
    # 1. Create the constructor function
    def __init__(self, custID="",empID="", name="", zip="",date="", amount="" ):
        self.__custID = custID
        self.__empID = empID
        self.__name = name
        self.__zip = zip
        self.__date = date
        self.__amount = amount

    # 2. Create a function that returns the name and year released
    def getStr(self):
        return self.__custID +self.__empID +self.__name + " ("  + str(self.__zip) + ")" + " ("  + str(self.__date) + ")"+ " ("  + str(self.__amount) + ")"

    @classmethod
    def getAllInvoices(cls):
        # A. Connection to the database
        con = sqlite3.connect('gc.db')

        # A1. Add in row_factory.  This will allow us to use column names instead
        #     of guess which column position number our data is in
        con.row_factory = sqlite3.Row

        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT * FROM Invoice;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        invoiceList = []

        for individualRow in allRows:
            c = {"InvoiceID" : individualRow["InvoiceID"],"CustomerID" : individualRow["CustomerID"],"EmployeeID" : individualRow["EmployeeID"], "Name" : individualRow["Name"], "ZIP": individualRow["ZIP"], "Date": individualRow["Date"], "Amount": individualRow["Amount"] }
            invoiceList.append(c)
        return invoiceList

class Staff:
    # 1. Create the constructor function
    def __init__(self, staffID=0,name="", position=""):
        self.__staffID = staffID
        self.__name = name
        self.__position = position

    # 2. Create a function that returns the name and year released
    def getStr(self):
        return self.__custID +self.__staffID +self.__name + " ("  + str(self.__position) + ")"

    @classmethod
    def getAllStaff(cls):
        # A. Connection to the database
        con = sqlite3.connect('gc.db')

        # A1. Add in row_factory.  This will allow us to use column names instead
        #     of guess which column position number our data is in
        con.row_factory = sqlite3.Row

        # B. Create a workspace (aka Cursor)
        cursorObj = con.cursor()

        # D. Run the SQL Select statement to retive the data
        cursorObj.execute('SELECT * FROM Staff;')

        # E. Tell Pyton to 'fetch' all of the records and put them in
        #     a list called allRows
        allRows = cursorObj.fetchall()

        staffList = []

        for individualRow in allRows:
            c = {"StaffID" : individualRow["StaffID"],"Name" : individualRow["Name"],"Position" : individualRow["Position"] }
            staffList.append(c)
        return staffList

class Material:
    # 1. Create the constructor function
    def __init__(self, partNum="", supplierNum="", supplierName="", prodName="", price=0, quantityAvailable=""):
        self.__partNum = partNum
        self.__supplierNum = supplierNum
        self.__supplierName = supplierName
        self.__prodName = prodName
        self.__price = price
        self.__quantityAvailable = quantityAvailable

    # 2. Create a function that returns the name and year released
    def getStr(self):
        return __partNum + " ("  + str(self.__partNum) + ")" + " ("  + str(self.__supplierNum) + ")"+ " ("  + str(self.__prodName) + ")"+ " ("  + str(self.__price) + ")"+ " ("  + str(self.__quantityAvailable) + ")"+ str(self.__supplierName)
    @classmethod
    def UpdateMaterialByPartNum(self,materials, quantity):
        for item in materials:
            # update Material table in the quantity where dict["PartNumber"] == SWPartNumber
            updateMaterialsQuantityDB(item["PartNumber"], (quantity * int(item["Quantity"])))







