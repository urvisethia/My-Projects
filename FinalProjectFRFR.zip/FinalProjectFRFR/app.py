###############################################################################
#                         IMPORT REQUIRED LIBRARIES/MODULES
###############################################################################
# 1. The FLASK framework (the webserver)
from flask import Flask

''' NEW NEW NEW NEW NEW NEW NEW NEW NEW '''
from flask import redirect, url_for #The FLASK framework (the webserver)
''' NEW NEW NEW NEW NEW NEW NEW NEW NEW '''


# 2. For opening and read the HTML file and showing them as the webpage
from flask import render_template

# 3. From the flask library import the request class.
# Allows us to get information from the website URL
from flask import request

# 4. From the objects.py containing our classes for this application, only import the Song class
from objects import *




# 5. Import the sqlite library
# import sqlite3

# 6. Instantiate the Flask() class and called it app
app = Flask(__name__)

# 7. Import your database functions from a separte file called database.py
from database import *


###############################################################################
#                         CREATE YOUR WEBPAGE ROUTES
###############################################################################

# -----------------------------------------------------------------------------
# A) Create your home page.  Let's call the page "index"
# -----------------------------------------------------------------------------

#   Start with a decorator with no name. That way when they only type in your server's name
#   It will got to this page
@app.route("/")

#   Let's also add the name "index" since that is a common name for a website home page
@app.route("/index")    # Decorator - Now

#   Define what should happen when visiting this page by using a function called index()
def hello_world():
    #return "Hello WORLD"
    # A1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
    sList=Song.getAllCustomers()

    #Return the template index.html but pass it the list of songs
    # stored in the variable sList
    return render_template('index.html',message=sList )



# -----------------------------------------------------------------------------
# B) Create a page to DELETE records
#------------------------------------------------------------------------------

# Create a decorator with the route/path "delete".
# IMPORTANT: THIS IS A FORM!!!
# Allowable Actions:
#   GET:  This is when you first come to the page
#   POST: This is when you SUBMIT the information that you filled out in the form
@app.route("/delete", methods=["GET","POST"]) # Decorator - Now

#   Define what should happen when visiting this page by using a function called delete
def delete():
    if request.method == "GET":  # When you first visit the page

        # B1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllCustomers()
        return render_template('delete.html',message=sList)

    elif request.method == "POST": # When you fill out the form and click SUBMIT
        # Get the value from the form object called "songname" (it is a textbox)
        songname = request.form.get("songname", 0)

        # B1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllCustomers()
        delSongs_Name_DB(songname)

        # B1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllSongs()

        #Return the template index.html but pass it the list of songs
        # stored in the variable mList
        return render_template('delete.html',message=sList )

    else:
        # How could it have not been a GET or POST? Hmm. Should have been one of them.
        return render_template('delete.html',message="Something did not work.")


#------------------------------------------------------------------------------------
# C) Create a page to INSERT records
#------------------------------------------------------------------------------------

@app.route("/add", methods=["GET","POST"]) # Decorator - Now
def add():
    if request.method == "GET":  # When you first visit the page

        # C1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllCustomers()
        return render_template('add.html',message=sList)

    elif request.method == "POST": # When you fill out the form and click SUBMIT
        # C1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllCustomers()

        # Get the value from the form object called "songname" (it is a textbox)
        name = request.form.get("custName", 0)
        zip = request.form.get("custZIP",0)
        telephone = request.form.get("custTelephone",0)
        email = request.form.get("custEmail",0)
        category = request.form.get("custCategory",0)

        # Run the function called saveSongDB passing the method the name of the song
        #   and the year the song was release
        saveCustomerDB(name, zip, telephone, email, category)

        # C1) Run a CLASS method called getAllSongs().  Instaniation is not needed.
        sList=Song.getAllCustomers()

        #Return the template index.html but pass it the list of songs
        # stored in the variable mList
        return render_template('add.html',message=sList )

    else:
        # How could it have not been a GET or POST? I have no idea how that could have happened.
        return render_template('add.html',message='Something went wrong.')

#------------------------------------------------------------------------------------
#D) Create a route to an image page
#------------------------------------------------------------------------------------
@app.route("/image") # Decorator for the best dog
def phoebe():
    return render_template('image.html')




''' NEW NEW NEW NEW NEW NEW NEW NEW NEW NEW  NEW  NEW  NEW  NEW  NEW  NEW  NEW  '''
# E) Create a route to list all songs with Delete, Edit, View options
#------------------------------------------------------------------------------------
@app.route("/list", methods=["GET","POST"]) # Decorator
def list():
    if request.method == "GET":
        sList=Song.getAllCustomers()
        return render_template('songList.html',message=sList)
    elif request.method == "POST":
        ID = getIntegerFormVariable("ID")
        sList=Song.getAllCustomers()
        #delEstimates_DB(ID)

        #Reload Estimate list as a dictionary
        #DETERMINE IF THIS IS USING A CSV FILE OR DATABASE
        sDict=Song.getAllCustomers()
        return render_template('songList.html',message=sDict )

#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
@app.route("/prodList", methods=["GET","POST"]) # Decorator
def prodList():
    if request.method == "GET":
        sList=Product.getAllProducts()
        return render_template('productList.html',message=sList)
    elif request.method == "POST":
        ID = getIntegerFormVariable("ID")
        sList=Product.getAllProducts()
        #delEstimates_DB(ID)

        #Reload Estimate list as a dictionary
        #DETERMINE IF THIS IS USING A CSV FILE OR DATABASE
        sDict=Product.getAllProducts()
        return render_template('productList.html',message=sDict )

#------------------------------------------------------------------------------------
@app.route("/suppList", methods=["GET","POST"]) # Decorator
def suppList():
    if request.method == "GET":
        sList=Supplier.getAllSuppliers()
        return render_template('supplierList.html',message=sList)
    elif request.method == "POST":
        ID = getIntegerFormVariable("ID")
        sList=Supplier.getAllSuppliers()
        #delEstimates_DB(ID)

        #Reload Estimate list as a dictionary
        #DETERMINE IF THIS IS USING A CSV FILE OR DATABASE
        sDict=Product.getAllSuppliers()
        return render_template('supplierList.html',message=sDict )

#------------------------------------------------------------------------------------
@app.route("/custEdit", methods=["GET","POST"]) # Decorator - Now
def editableList():
    if request.method == "GET":
        sList=Song.getAllCustomers()
        return render_template('editList.html',message=sList)
    elif request.method == "POST":
        ID = getIntegerFormVariable("ID")
        sList=Song.getAllCustomers()
        #delEstimates_DB(ID)

        #Reload Estimate list as a dictionary
        #DETERMINE IF THIS IS USING A CSV FILE OR DATABASE
        cDict=Song.getAllCustomers()
        return render_template('editList.html',message=cDict )



#E) Create a route to EDIT an individual song
#------------------------------------------------------------------------------------
# NOTE**** THIS EDIT HAS <int:ID> added to it
@app.route("/Edit/<int:ID>", methods=['POST', 'GET'])
def EditFUNCTION(ID):
    if request.method == "GET":
        # GET THE SONG FOR THE ID
        sSingleDict=getSingleDictList_DB(ID)
        # PASS THE SINGLE SONG TO THE edit.html PAGE
        return render_template('edit.html',message=sSingleDict )

#------------------------------------------------------------------------------------
#E) Create a route to SAVE an individual song after EDIT
#------------------------------------------------------------------------------------

@app.route("/Edit", methods=["GET","POST"]) # Decorator - Now
def EditSave():
    # GET THE VALUES FROM THE FORM - USE THE FUNCTIONS AT THE BOTTOM OF THIS
    # CODE PAGE TO HELP YOU GET THE VALUSE
        ID = getIntegerFormVariable("cID")
        name = getFormVariable("cName")
        zip = getFormVariable("cZIP")
        telephone = getFormVariable("cTelephone")
        email = getFormVariable("cEmail")
        category = getFormVariable("cCategory")


        # CALL THE FUNCTION updateSongDB and pass the new values
        xID = updateSongDB(
                ID,
                name,
                zip,
                telephone,
                email,
                category)
        # Retrive the new values from the database and ...
        sSingleDict=getSingleDictList_DB(ID)
        # display it on the display.html page
        return render_template('display.html',message=sSingleDict)

# NOTE**** THIS EDIT DOES NOT HAVE THE <int:ID> added to it
@app.route("/createOrder" , methods=["GET","POST"])    # Decorator - Now
# there should be a form and the list of orders should load as well
def ordersSave():
    if request.method == "GET":
        pList=Product.getAllProducts()
        cList = Song.getAllCustomers()
        sList = Staff.getAllStaff()
        iList = Invoice.getAllInvoices()
        return render_template('orders.html',message=[pList,cList,sList,iList])

    elif request.method == "POST":
        totalOrders = 1
        submittedOrders = 0
        # get the product id variable
        ID1 = getIntegerFormVariable("prod1")
        quantity1 = getIntegerFormVariable("quantity1")
        # get the material and quantities needed for the selected product
        neededMaterials1 = Product.getBOMByID(ID1) # dictionary
        # print(neededMaterials1)
        result1 = Product.enoughMaterials(neededMaterials1, quantity1)

        if result1 == True:
            submittedOrders = submittedOrders + 1
            # add order to invoice table
            print("True")
            custID = getIntegerFormVariable("customerID")
            empID = getIntegerFormVariable("staffID")
            amount = Product.getProdPriceByID(ID1)
            amount= amount[0]['Price'] * int(quantity1)
            cust = Song.getSingleCustomer(custID)
            print("customer name")
            print(cust)
            name = cust[0]["Name"]
            zip = cust[0]["ZIP"]
            todayDate = date.today()
            saveOrderDB(custID, empID,name, zip,todayDate, amount)
            Material.UpdateMaterialByPartNum(neededMaterials1, quantity1)


######## order 2
        if getIntegerFormVariable("quantity2") != "":
            totalOrders = totalOrders + 1
            ID2 = getIntegerFormVariable("prod2")
            quantity2 = getIntegerFormVariable("quantity2")
            # get the material and quantities needed for the selected product
            neededMaterials2 = Product.getBOMByID(ID2)
            # print(neededMaterials1)
            result2 = Product.enoughMaterials(neededMaterials2, quantity2)
            if result2 == True:
                submittedOrders = submittedOrders + 1
                # add order to invoice table
                print("True")
                custID = getIntegerFormVariable("customerID")
                empID = getIntegerFormVariable("staffID")
                amount = Product.getProdPriceByID(ID1)
                amount= amount[0]['Price'] * quantity2
                cust = Song.getSingleCustomer(custID)
                print("customer name")
                print(cust)
                name = cust[0]["Name"]
                zip = cust[0]["ZIP"]
                todayDate = date.today()
                saveOrderDB(custID, empID,name, zip,todayDate, amount)

######## order 3
        if getIntegerFormVariable("quantity3") != "":
            totalOrders = totalOrders + 1
            ID3 = getIntegerFormVariable("prod3")
            quantity3 = getIntegerFormVariable("quantity3")
            # get the material and quantities needed for the selected product
            neededMaterials3 = Product.getBOMByID(ID3)
            # print(neededMaterials1)
            result3 = Product.enoughMaterials(neededMaterials3, quantity3)
            if result3 == True:
                submittedOrders = submittedOrders + 1
                # add order to invoice table
                print("True")
                custID = getIntegerFormVariable("customerID")
                empID = getIntegerFormVariable("staffID")
                amount = Product.getProdPriceByID(ID1)
                amount= amount[0]['Price'] * quantity3
                cust = Song.getSingleCustomer(custID)
                print("customer name")
                print(cust)
                name = cust[0]["Name"]
                zip = cust[0]["ZIP"]
                todayDate = date.today()
                saveOrderDB(custID, empID,name, zip,todayDate, amount)


##### order 4
        if getIntegerFormVariable("quantity4") != "":
            totalOrders = totalOrders + 1
            ID4 = getIntegerFormVariable("prod4")
            quantity4 = getIntegerFormVariable("quantity4")
            # get the material and quantities needed for the selected product
            neededMaterials4 = Product.getBOMByID(ID4)
            result4 = Product.enoughMaterials(neededMaterials4, quantity4)
            if result4 == True:
                submittedOrders = submittedOrders + 1
                # add order to invoice table
                print("True")
                custID = getIntegerFormVariable("customerID")
                empID = getIntegerFormVariable("staffID")
                amount = Product.getProdPriceByID(ID1)
                amount= amount[0]['Price'] * quantity4
                cust = Song.getSingleCustomer(custID)
                print("customer name")
                print(cust)
                name = cust[0]["Name"]
                zip = cust[0]["ZIP"]
                todayDate = date.today()
                saveOrderDB(custID, empID,name, zip,todayDate, amount)

##### order 5
        if getIntegerFormVariable("quantity5") != "":
            totalOrders = totalOrders + 1
            ID5 = getIntegerFormVariable("prod5")
            quantity5 = getIntegerFormVariable("quantity5")
            # get the material and quantities needed for the selected product
            neededMaterials5 = Product.getBOMByID(ID5)
            # print(neededMaterials1)
            result5 = Product.enoughMaterials(neededMaterials5, quantity5)
            if result5 == True:
                submittedOrders = submittedOrders + 1
                # add order to invoice table
                print("True")
                custID = getIntegerFormVariable("customerID")
                empID = getIntegerFormVariable("staffID")
                amount = Product.getProdPriceByID(ID1)
                amount= amount[0]['Price'] * quantity5
                cust = Song.getSingleCustomer(custID)
                name = cust[0]["Name"]
                zip = cust[0]["ZIP"]
                todayDate = date.today()
                saveOrderDB(custID, empID,name, zip,todayDate, amount)

        # pass in needed materials and check the amounts
        # if function returns "true" then add to the invoice table

        if totalOrders == submittedOrders:
            return render_template('successSubmit.html',message = totalOrders)
        else:
            return render_template('failSubmit.html',message=[submittedOrders, totalOrders])

#------------------------------------------------------------------------------------
#E) Create a route to DISPLAY a single song
#------------------------------------------------------------------------------------
@app.route("/Display/<int:ID>", methods=['POST', 'GET'])
def DisplayFUNCTION(ID):
    # GET THE SONG FOR THE ID
    sSingleDict=getSingleDictList_DB(ID)
    # PASS THE SINGLE SONG TO THE edit.html PAGE
    return render_template('display.html',message=sSingleDict )

# 1. FUNCTION TO HELP GET VARIABLES FROM FORMS
#---------------------------
def getFormVariable(variableName):
    return request.form.get(variableName, 0)

def getIntegerFormVariable(variableName):
    return request.form.get(variableName, 0)

if __name__ == '__main__':
    app.run(debug=True)

