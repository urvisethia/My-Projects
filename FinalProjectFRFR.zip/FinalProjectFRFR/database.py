# A. Import the sqlite library
import sqlite3

# B. From the objects.py containing our classes for this application,
#    only import the Song class
from objects import *
from datetime import date


########################################################################################

#-------------------------------------
# 1. DELETE Song FROM DB by Name
#-------------------------------------
def delSongs_Name_DB(name):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")

    #B. Write a SQL statement to delete a specific row (based on Name name)
    sql='DELETE FROM songs WHERE Name=?'

    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (name,))

    # D. Save the changes
    conn.commit()


#-------------------------------------
# 2. ADD SONG FROM DB
#-------------------------------------
def saveCustomerDB(name, zip,telephone,email,category):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")

    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='INSERT INTO customer (Name, Zip,Telephone,Email,Category) values (?,?,?,?,?)'


    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (name,zip,telephone,email,category,))

    # D. Save the changes
    conn.commit()

#-------------------------------------
def saveInvoiceDB(customerID, employeeID,name,zip,date,amount):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")

    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='INSERT INTO Invoice (CustomerID, EmployeeID,Name,ZIP,Date,Amount) values (?,?,?,?,?,?)'

    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (customerID, employeeID,name,zip,date,amount,))

    # D. Save the changes
    conn.commit()
# 3. Get single song
#-------------------------------------
def getSingleDictList_DB(ID):
    con = sqlite3.connect('gc.db')
    con.row_factory = sqlite3.Row
    cursorObj = con.cursor()
    cust = []
    cursorObj.execute('SELECT * FROM customer where CustomerID = ?;',(ID,))
    rows = cursorObj.fetchall()
    for individualRow in rows:
        s = {"CustomerID" : individualRow["CustomerID"], "Name" : individualRow["Name"], "ZIP": individualRow["ZIP"], "Telephone": individualRow["Telephone"], "Email": individualRow["Email"], "Category": individualRow["Category"] }
        cust.append(s)
    return cust

#-------------------------------------
# 4. UPDATE SONG FROM DB
#-------------------------------------
def updateSongDB(ID, name, zip, telephone, email, category):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")
    #print(name)
    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='UPDATE customer set Name = ?, ZIP=? , Telephone=?, Email=?, Category=? where CustomerID = ?;'

    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (name,zip,telephone, email, category,ID,))

    # D. Save the changes
    conn.commit()
# update the quantity available page so that materials used to create the invoice are subtracted
def updateMaterialsDB(ID, name, zip, telephone, email, category):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")
    #print(name)
    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='UPDATE customer set Name = ?, ZIP=? , Telephone=?, Email=?, Category=? where CustomerID = ?;'

    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (name,zip,telephone, email, category,ID,))

    # D. Save the changes
    conn.commit()

def updateMaterialsQuantityDB(id, subtractedQuantity):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")
    #print(name)
    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='UPDATE Materials set QuantityAvailable = QuantityAvailable - ? WHERE SWPartNum = ?'

    # B. Create a workspace (aka Cursor)
    cur = conn.cursor()

    # C. Run the SQL statement from above and pass it 1 parameter for each ?
    cur.execute(sql, (subtractedQuantity, id,))

    # D. Save the changes
    conn.commit()

#-------------------------------------
# 5. DELETE SONG FROM DB by ID
#-------------------------------------
def delSongs_DB(ID):
    database = "gc.db"
    # create a database connection
    conn = None
    conn = sqlite3.connect(database)
    sql='DELETE FROM Songs WHERE ID=?'
    cur = conn.cursor()
    cur.execute(sql, (ID,))
    conn.commit()
# try to save an order. If you have the neccesary materials then you add it, else send a message like not enough materials
def saveOrderDB(custID, empID,name,zip, date, amount):
    #A. Make a connection to the database
    conn = None
    conn = sqlite3.connect( "gc.db")

    #B. Write a SQL statement to insert a specific row (based on Name name)
    sql='INSERT INTO invoice (CustomerID, EmployeeID,Name,ZIP,Date, Amount) values (?,?,?,?,?,?)'
    cur = conn.cursor()

    cur.execute(sql, (custID,empID,name,zip,date, amount,))

    # D. Save the changes
    conn.commit()
